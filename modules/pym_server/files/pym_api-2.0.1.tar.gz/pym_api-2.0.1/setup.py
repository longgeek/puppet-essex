from setuptools import setup, find_packages

setup(
    name = "pym_api",
    version = "2.0.1",
    author = 'xcluo',
    author_email = 'xcluo.mr@gmail.com',
    description = 'Pymonitor API',

    packages = find_packages(),
    keywords = ('pymonitor', 'monitor', 'python'),
    ##cmdclass = cmdclasses,
    ##data_files = data_files,
    #scripts = ['scripts/pymapi.py'],
)
